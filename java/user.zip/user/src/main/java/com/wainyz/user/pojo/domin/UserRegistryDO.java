package com.wainyz.user.pojo.domin;

import lombok.Data;

/**
 * @author Yanion_gwgzh
 */
@Data
public class UserRegistryDO {
    String email;
    String emailCode;
    String password;
}
