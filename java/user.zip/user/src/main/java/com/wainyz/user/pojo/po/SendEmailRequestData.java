package com.wainyz.user.pojo.po;

import lombok.Data;

/**
 * @author Yanion_gwgzh
 */
@Data
public class SendEmailRequestData {
    public String email;
    public String imageId;
    public String imageCode;
}
