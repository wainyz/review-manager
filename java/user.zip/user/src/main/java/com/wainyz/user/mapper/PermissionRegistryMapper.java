package com.wainyz.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wainyz.user.pojo.po.PermissionRegistry;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PermissionRegistryMapper extends BaseMapper<PermissionRegistry> {
}
