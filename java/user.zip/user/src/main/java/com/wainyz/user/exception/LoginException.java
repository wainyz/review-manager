package com.wainyz.user.exception;



/**
 * @author Yanion_gwgzh
 */
public class LoginException extends Exception{
    public LoginException() {
        super();
    }
    public LoginException(String message) {
        super(message);
    }

}
